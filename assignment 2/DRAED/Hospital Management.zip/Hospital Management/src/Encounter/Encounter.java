/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Encounter;

import Vitals.Vitals;

/**
 *
 * @author BARATHI
 */
public class Encounter extends Vitals {
    protected String UpdateTime;

    public void setUpdateTime(String UpdateTime) {
        this.UpdateTime = UpdateTime;
    }

    public String getUpdateTime() {
        return UpdateTime;
    }
}
