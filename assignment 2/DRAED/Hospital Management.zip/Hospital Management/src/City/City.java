/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package City;

/**
 *
 * @author BARATHI
 */
public class City {
    protected String City;

    public void setCity(String City) {
        this.City = City;
    }

    public String getCity() {
        return City;
    }
}
