/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Residence;

import Community.Community;

/**
 *
 * @author BARATHI
 */
public class Residence extends Community {
    protected String Residence;

    public void setResidence(String Residence) {
        this.Residence = Residence;
    }

    public String getResidence() {
        return Residence;
    }
}
