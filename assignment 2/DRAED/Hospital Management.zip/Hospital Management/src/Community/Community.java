/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Community;

import City.City;

/**
 *
 * @author BARATHI
 */
public class Community extends City {
    protected String Community;

    public void setCommunity(String Community) {
        this.Community = Community;
    }

    public String getCommunity() {
        return Community;
    }
}
